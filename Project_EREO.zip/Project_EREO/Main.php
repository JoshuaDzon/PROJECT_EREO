<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">                     
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Reservation for Event Organizer</title>
    <link rel="stylesheet" href="Main.css">
    <link rel="icon" type="image/png" href="images/logo.jpg">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body>

    <!-- Navbar -->
    <nav class="navbar">
        <div class="nav-left">
            <img src="images/ERFEOlogo.png" alt="" class="logo-img">
        </div>
        <ul class="nav-links">
            <li><a href="Main.php" class="nav-item active">HOME</a></li>
            <li><a href="event_reservation.php" class="nav-item">Booking Reserve</a></li>
            <li><a href="contact.php" class="nav-item">ABOUT US</a></li>
            <li class="account-dropdown">
                <a href="#" class="nav-item">
                    <img src="images/pfp.jpg" alt="Account" class="account-icon">
                </a>
                <ul class="dropdown-menu">
                    <li><a href="#" onclick="showRegister()">Register</a></li>
                    <li><a href="#" onclick="showLogin()">Login</a></li>
                </ul>
            </li>
        </ul>
    </nav>

    <!-- Hero Section -->
    <main class="hero-section">
        <div class="hero-content">
            <h1>WELCOME TO ERFEO</h1>
            <p>Making Every Event Memorable</p>
            <p>Plan, reserve, and celebrate your events with ease.</p>
        </div>
    </main>

    <!-- Register Modal -->
    <div class="modal-backdrop" id="registerModal">
        <div class="modal-content">
            <span class="close-btn" onclick="closeModal('registerModal')">&times;</span>
            <div class="modal-header">
                <h4>Register for a new account</h4>
            </div>
            <form action="register.php" method="post">
                <input type="text" name="username" placeholder="Enter Username" required>
                <input type="password" name="password" placeholder="Enter Password" required>
                <input type="password" name="confirm_password" placeholder="Confirm Password" required>
                <button type="submit" class="modal-btn">Register</button>
            </form>
        </div>
    </div>

    <!-- Login Modal -->
    <div class="modal-backdrop" id="loginModal">
        <div class="modal-content">
            <span class="close-btn" onclick="closeModal('loginModal')">&times;</span>
            <div class="modal-header">
                <h4>Log In to your account</h4>
            </div>
            <form action="login.php" method="post">
                <input type="text" name="username" placeholder="Enter Username" required>
                <input type="password" name="password" placeholder="Enter Password" required>
                <button type="submit" class="modal-btn">Log In</button>
            </form>
        </div>
    </div>

    <!-- Footer -->
    <footer class="site-footer">
        &copy; 2025 Event Reservation for Event Organizer. All rights reserved.
    </footer>

    <!-- Scripts -->
    <script>
        function showRegister() {
            document.getElementById('registerModal').style.display = 'flex';
        }

        function showLogin() {
            document.getElementById('loginModal').style.display = 'flex';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        // Close modal if clicked outside
        window.onclick = function(event) {
            const registerModal = document.getElementById('registerModal');
            const loginModal = document.getElementById('loginModal');
            if (event.target == registerModal) registerModal.style.display = "none";
            if (event.target == loginModal) loginModal.style.display = "none";
        }
    </script>

</body>
</html>
