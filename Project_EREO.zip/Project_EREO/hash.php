<?php
echo password_hash('Admin_@EREO*****', PASSWORD_DEFAULT);
?>
